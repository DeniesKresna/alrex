<template>
<div>
	<v-footer app>
      <span>Denies Kresna B &copy; 2019</span>
    </v-footer>
</div>
</template>
<script>
</script>