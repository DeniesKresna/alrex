<template>
<div>
	<v-row>
		<v-col cols="12">
			<div class="title">Dashboard</div>
		</v-col>
	</v-row>
</div>
</template>
<script>
</script>