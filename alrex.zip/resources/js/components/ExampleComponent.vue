<template>
    <div>
        <v-card class="mx-auto">
        	<v-card-title>Selamat Datang</v-card-title>
		    <v-card-text>Halo ini sementara untuk Aplikasi Inventaris permintaanya sarpras</v-card-text>
		    <!--<v-card-actions>
		      <v-btn text>Click</v-btn>
		    </v-card-actions>-->
        </v-card>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('App Start')
        }
    }
</script>
